// src/components/Auth.js
import { auth, provider } from '../firebase';
import { signInWithPopup, signOut } from 'firebase/auth';

function Auth({ setUser }) {
  const login = async () => {
    const result = await signInWithPopup(auth, provider);
    setUser(result.user);
  };

  const logout = () => {
    signOut(auth);
    setUser(null);
  };

  return (
    <div>
      <button onClick={login}>Login with Google</button>
      <button onClick={logout}>Logout</button>
    </div>
  );
}
export default Auth;
