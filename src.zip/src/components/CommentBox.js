// src/components/CommentBox.js
import { useState, useEffect } from 'react';
import axios from 'axios';

function CommentBox({ storyId, user }) {
  const [comments, setComments] = useState([]);
  const [text, setText] = useState('');

  const fetchComments = async () => {
    const res = await axios.get(`http://localhost:5000/api/comments/${storyId}`);
    setComments(res.data);
  };

  useEffect(() => {
    fetchComments();
  }, [storyId]);

  const handleSubmit = async () => {
    const newComment = {
      storyId,
      userName: user.displayName,
      userEmail: user.email,
      userImage: user.photoURL,
      commentText: text,
      createdAt: new Date()
    };

    const res = await axios.post('http://localhost:5000/api/comments', newComment);
    setComments([res.data, ...comments]);
    setText('');
  };

  return (
    <div>
      <h3>Comments</h3>
      {user ? (
        <>
          <textarea value={text} onChange={e => setText(e.target.value)} placeholder="Add a comment..." />
          <button onClick={handleSubmit}>Post Comment</button>
        </>
      ) : (
        <p>Please log in to comment.</p>
      )}

      <ul>
        {comments.map((c, idx) => (
          <li key={idx}>
            <img src={c.userImage} alt="profile" width="30" />
            <strong>{c.userName}</strong>: {c.commentText}
            <br /><small>{new Date(c.createdAt).toLocaleString()}</small>
          </li>
        ))}
      </ul>
    </div>
  );
}
export default CommentBox;

