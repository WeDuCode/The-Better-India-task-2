import { useState } from 'react';
import Auth from './components/Auth';
import CommentBox from './components/CommentBox';

function App() {
  const [user, setUser] = useState(null);
  const storyId = "story-123"; // Replace with dynamic ID per story

  return (
    <div>
      <h1>Story Title</h1>
      <p>Story content...</p>

      <Auth setUser={setUser} />
      <CommentBox storyId={storyId} user={user} />
    </div>
  );
}

export default App;
